package com.example.gonzalo_sanchez_semana5

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var videoViewLogo: VideoView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val buttonViewList: Button = findViewById(R.id.buttonViewList)
        val buttonCapturePhoto: Button = findViewById(R.id.buttonCapturePhoto)
        val buttonShowChart: Button = findViewById(R.id.buttonShowChart)
        videoViewLogo = findViewById(R.id.videoViewLogo)

        // Configurar VideoView
        val videoPath = "android.resource://" + packageName + "/" + R.raw.logo
        val uri = Uri.parse(videoPath)
        videoViewLogo.setVideoURI(uri)
        videoViewLogo.setOnPreparedListener { it.isLooping = true }
        videoViewLogo.start()

        buttonViewList.setOnClickListener {
            val intent = Intent(this, VendorListActivity::class.java)
            startActivity(intent)
        }

        buttonCapturePhoto.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), REQUEST_IMAGE_CAPTURE)
            } else {
                dispatchTakePictureIntent()
            }
        }

        buttonShowChart.setOnClickListener {
            val intent = Intent(this, SalesChartActivity::class.java)
            startActivity(intent)
        }
    }

    private fun dispatchTakePictureIntent() {
        val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        try {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            val imageBitmap = data?.extras?.get("data") as Bitmap
            // Aquí puedes manejar la imagen capturada
        }
    }

    companion object {
        const val REQUEST_IMAGE_CAPTURE = 1
    }
}
