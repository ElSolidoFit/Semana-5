package com.example.gonzalo_sanchez_semana5

data class Vendor(val name: String, val area: String, val photoResId: Int, val sales: Int = (0..100).random())
