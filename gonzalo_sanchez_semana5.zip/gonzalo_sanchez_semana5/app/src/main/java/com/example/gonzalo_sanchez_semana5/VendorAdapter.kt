package com.example.gonzalo_sanchez_semana5

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView

class VendorAdapter(context: Context, vendors: List<Vendor>) : ArrayAdapter<Vendor>(context, 0, vendors) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view = convertView
        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.vendor_item, parent, false)
        }

        val vendor = getItem(position)
        val imageView = view?.findViewById<ImageView>(R.id.imageView)
        val nameTextView = view?.findViewById<TextView>(R.id.nameTextView)
        val areaTextView = view?.findViewById<TextView>(R.id.areaTextView)

        vendor?.let {
            imageView?.setImageResource(it.photoResId)
            nameTextView?.text = it.name
            areaTextView?.text = it.area
        }

        return view!!
    }
}
