package com.example.gonzalo_sanchez_semana5

import android.annotation.SuppressLint
import android.media.MediaPlayer
import android.os.Bundle
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class VendorListActivity : AppCompatActivity() {

    private lateinit var listViewVendors: ListView
    private lateinit var mediaPlayer: MediaPlayer
    private lateinit var vendors: List<Vendor>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vendor_list)

        // Habilitar el Up Button
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        listViewVendors = findViewById(R.id.listViewVendors)

        // Initialize the vendor list
        vendors = listOf(

            Vendor("Alexis Salazar", "Electronica", R.drawable.vendor1),
            Vendor("Mauricio Barra", "Computacion", R.drawable.vendor2),
            Vendor("Marcelo Chavez", "Hogar", R.drawable.vendor3),
            Vendor("Camilo Lazo", "Deportes", R.drawable.vendor4),
            Vendor("Pedro Jofre", "Escolar", R.drawable.vendor5)
        )

        val adapter = VendorAdapter(this, vendors)
        listViewVendors.adapter = adapter

        listViewVendors.setOnItemClickListener { _, _, position, _ ->
            if (position == 2) { // Third vendor
                mediaPlayer = MediaPlayer.create(this, R.raw.sample_audio)
                mediaPlayer.start()
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
