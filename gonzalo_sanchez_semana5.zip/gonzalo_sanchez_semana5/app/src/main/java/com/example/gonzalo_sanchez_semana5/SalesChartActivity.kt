package com.example.gonzalo_sanchez_semana5


import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.utils.ColorTemplate

class SalesChartActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sales_chart)

        // Habilitar el Up Button
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val barChart: BarChart = findViewById(R.id.barChart)

        // Datos de ejemplo
        val vendors = listOf(
            Vendor("Alexis Salazar", "Electronica", R.drawable.vendor1, sales = 100),
            Vendor("Mauricio Barra", "Computacion", R.drawable.vendor2, sales = 150),
            Vendor("Marcelo Chavez", "Hogar", R.drawable.vendor3, sales = 200),
            Vendor("Camilo Lazo", "Deportes", R.drawable.vendor4, sales = 250),
            Vendor("Pedro Jofre", "Escolar", R.drawable.vendor5, sales = 300)
        )

        val entries = ArrayList<BarEntry>()
        for ((index, vendor) in vendors.withIndex()) {
            entries.add(BarEntry(index.toFloat(), vendor.sales.toFloat()))
        }

        val dataSet = BarDataSet(entries, "Ventas")
        dataSet.colors = ColorTemplate.MATERIAL_COLORS.toList()
        val data = BarData(dataSet)

        barChart.data = data
        barChart.invalidate()
    }

    override fun onSupportNavigateUp(): Boolean {

        return true
    }
}
